execute at @s run clear @n[type=minecraft:player,nbt={Inventory:[{id:"minecraft:music_disc_13"}]},distance=..3] minecraft:music_disc_13[minecraft:custom_data="{golden_dandelion: true}"] 1



data merge entity @s {Age:-999999999}


tag @s add golden_dandelion_locked

execute at @s positioned ~ ~1 ~ run particle minecraft:happy_villager ~ ~ ~ 0.3 0.3 0.3 0 10