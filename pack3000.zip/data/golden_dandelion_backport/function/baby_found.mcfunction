execute as @e[distance=..2] if entity @s[nbt={Age:0},distance=..1] run tag @s add golden_dandelion_adult



execute as @e[distance=..2] unless entity @s[tag=golden_dandelion_adult] if entity @s[nbt={InLove:0}] run tag @s add golden_dandelion_baby




execute as @n[tag=golden_dandelion_baby] unless entity @s[tag=golden_dandelion_locked] run tag @s add golden_dandelion_ignore


execute as @n[tag=golden_dandelion_baby] unless entity @s[tag=golden_dandelion_locked] run function golden_dandelion_backport:age_locking



execute as @n[tag=golden_dandelion_baby] if entity @s[tag=golden_dandelion_locked] unless entity @s[tag=golden_dandelion_ignore] run function golden_dandelion_backport:age_unlocking


tag @e remove golden_dandelion_ignore