advancement revoke @s only golden_dandelion_backport:golden_dandelion_used


execute at @s unless entity @s[scores={golden_dandelion_cooldown=1..}] if entity @e[type=!player,distance=..5] anchored eyes positioned ^ ^-0.3 ^ run function golden_dandelion_backport:golden_dandelion_raycast


scoreboard players set @s golden_dandelion_cooldown 4

schedule function golden_dandelion_backport:golden_timer 1t